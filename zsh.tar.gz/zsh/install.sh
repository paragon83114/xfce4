termux-change-repo
pkg update
pkg upgrade
pkg install git zsh
sh -c "$(curl -fsSL https://raw.githubusercontent.com/ohmyzsh/ohmyzsh/master/tools/install.sh)"
git clone --depth=1 https://github.com/romkatv/powerlevel10k.git "${ZSH_CUSTOM:-$HOME/.oh-my-zsh/custom}/themes/powerlevel10k"
pkg install lsd
pkg install ranger
pkg install bat
pkg install python-pip
pkg install sox
cp /data/data/com.termux/files/home/zsh/termux.properties /data/data/com.termux/files/home/.termux/termux.properties
cp /data/data/com.termux/files/home/zsh/zshrc /data/data/com.termux/files/home/.zshrc
cp /data/data/com.termux/files/home/zsh/p10k.zsh /data/data/com.termux/files/home/.p10k.zsh
